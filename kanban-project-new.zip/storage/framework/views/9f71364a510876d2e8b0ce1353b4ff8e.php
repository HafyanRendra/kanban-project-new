<?php $__env->startSection('pageTitle', $pageTitle); ?>

<?php $__env->startSection('main'); ?>
  <div class="form-container">
    <h1 class="form-title"><?php echo e($pageTitle); ?></h1>
    <form class="form" method="POST" action="<?php echo e(route('auth.login')); ?>">
      <?php echo csrf_field(); ?>
      <div class="form-item">
        <label>Email:</label>
        <input class="form-input" type="text" value="<?php echo e(old('email')); ?>" name="email" required>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="form-item">
        <label>Password:</label>
        <input class="form-input" type="password" value="" name="password" required>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <button type="submit" class="form-button">Submit</button>
    </form>

    <p class="auth-link">You don't have an account? <a href="<?php echo e(route('auth.signup')); ?>">Register here</a></p>
    
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kanban-project-new\resources\views/auth/login_form.blade.php ENDPATH**/ ?>