<div class="sidebar">
  <div class="sidebar-container">
    <a class="sidebar-link" href="<?php echo e(route('home')); ?>">
      <span class="material-icons sidebar-icon">home</span>
      <p class="sidebar-text">Home</p>
    </a>
    <a class="sidebar-link" href="<?php echo e(route('tasks.index')); ?>">
      <span class="material-icons sidebar-icon">list</span>
      <p class="sidebar-text">Task List</p>
    </a>
    <!-- Tambahkan tautan menuju task.progress -->
    <a class="sidebar-link" href="<?php echo e(route('tasks.progress')); ?>">
      <span class="material-icons sidebar-icon">check_box</span>
      <p class="sidebar-text">Task Progress</p>
    </a>
   
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('viewUsersAndRoles', App\Models\Role::class)): ?>
    <a class="sidebar-link" href="<?php echo e(route('users.index')); ?>">
      <span class="material-icons sidebar-icon">group</span>
      <p class="sidebar-text">Users</p>
    </a>
     <?php endif; ?>
  
     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manageUserRoles', App\Models\Role::class)): ?>
    <a class="sidebar-link" href="<?php echo e(route('roles.index')); ?>">
      <span class="material-icons sidebar-icon">settings</span>
      <p class="sidebar-text">Roles</p>
    </a>
    <?php endif; ?>
    
    <!-- Tambahkan code dibawah -->
    <?php if(Auth::check()): ?>
      <a class="sidebar-link" href=""
        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <span class="material-icons sidebar-icon">logout</span>
        <p class="sidebar-text">Logout</p>
      </a>
      <form id="logout-form" action="<?php echo e(route('auth.logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
      </form>
    <?php endif; ?>
   
  </div>
</div><?php /**PATH C:\xampp\htdocs\kanban-project-new\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>